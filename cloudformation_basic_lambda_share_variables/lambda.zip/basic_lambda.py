def handler(event, context):
    console.log("hello world");
    return "hello world";

